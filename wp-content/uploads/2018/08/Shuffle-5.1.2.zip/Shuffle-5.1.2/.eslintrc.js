module.exports = {
  extends: '@odopod',
};

