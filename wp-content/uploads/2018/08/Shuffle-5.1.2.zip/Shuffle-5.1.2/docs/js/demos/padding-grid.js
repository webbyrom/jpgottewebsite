window.shuffleInstance = new window.Shuffle(document.getElementById('grid'), {
  itemSelector: '.grid__brick',
  sizer: '.my-sizer-element',
});
